// src/components/layout/AppLayout.jsx
import { NavLink, useNavigate } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";
import {
  HomeIco, GrpIco, MemIco, AttIco, MsgIco, SetIco, StarIco, LogoutIco,
} from "../ui/Icons";

const AbsenteesIco = () => <span style={{fontSize:18}}>📋</span>;

const MAIN_NAV = [
  { to: "/",            label: "Home",         Icon: HomeIco },
  { to: "/groups",      label: "Groups",       Icon: GrpIco  },
  { to: "/members",     label: "Members",      Icon: MemIco  },
  { to: "/attendance",  label: "Attendance",   Icon: AttIco  },
  { to: "/absentees",   label: "Absentees",    Icon: AbsenteesIco },
  { to: "/firsttimers", label: "First Timers", Icon: StarIco },
  { to: "/messaging",   label: "Messaging",    Icon: MsgIco  },
  { to: "/analytics",   label: "Analytics",    Icon: () => <span style={{fontSize:16}}>📊</span> },
  { to: "/settings",    label: "Settings",     Icon: SetIco  },
];

// Bottom nav — 5 most-used on mobile
// Absentees replaces Groups (Groups is always accessible via sidebar)
const BOTTOM_NAV = [
  { to: "/",            label: "Home",      Icon: HomeIco      },
  { to: "/attendance",  label: "Attend",    Icon: AttIco       },
  { to: "/absentees",   label: "Absentees", Icon: AbsenteesIco },
  { to: "/firsttimers", label: "Visitors",  Icon: StarIco      },
  { to: "/messaging",   label: "Message",   Icon: MsgIco       },
];

export function AppLayout({ children }) {
  const { signOut, church } = useAuth();
  const navigate = useNavigate();

  const handleLogout = () => { signOut(); navigate("/login"); };

  const navCls = ({ isActive }) => `ni ${isActive ? "act" : ""}`;
  const bnCls  = ({ isActive }) => `bni ${isActive ? "act" : ""}`;

  return (
    <div className="shell">
      {/* ── Desktop Sidebar ── */}
      <nav className="sb">
        <div className="sb-logo" onClick={() => navigate("/")} style={{ cursor:"pointer" }}>
          <h2>⛪ ChurchTrakr</h2>
          <p>{church?.name ?? "Loading…"}</p>
        </div>
        <div className="sb-nav">
          {MAIN_NAV.map(n => (
            <NavLink key={n.to} to={n.to} end={n.to === "/"} className={navCls}>
              <n.Icon /> {n.label}
            </NavLink>
          ))}
        </div>
        <div className="sb-foot">
          <button className="ni" onClick={handleLogout}>
            <LogoutIco /> Sign Out
          </button>
        </div>
      </nav>

      {/* ── Main content ── */}
      <main className="main">{children}</main>

      {/* ── Mobile Bottom Nav ── */}
      <nav className="bnav">
        <div className="bnav-inner">
          {BOTTOM_NAV.map(n => (
            <NavLink key={n.to} to={n.to} end={n.to === "/"} className={bnCls}>
              <n.Icon />
              <span>{n.label}</span>
            </NavLink>
          ))}
        </div>
      </nav>
    </div>
  );
}