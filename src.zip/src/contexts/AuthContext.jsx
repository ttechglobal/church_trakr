// src/contexts/AuthContext.jsx
import { createContext, useContext, useState, useEffect, useCallback } from "react";
import { supabase } from "../services/supabaseClient";

const AuthContext = createContext(null);

async function fetchChurch(userId) {
  if (!userId) return null;
  const { data, error } = await supabase
    .from("churches")
    .select("*")
    .eq("admin_user_id", userId)
    .maybeSingle();
  if (error) console.error("[fetchChurch]", error.code, error.message);
  return data ?? null;
}

export function AuthProvider({ children }) {
  const [user,   setUser]   = useState(undefined); // undefined = still loading
  const [church, setChurch] = useState(null);

  const loading         = user === undefined;
  const isAuthenticated = !!user && user !== undefined;

  useEffect(() => {
    // onAuthStateChange is the ONLY place we set user+church.
    // It fires for INITIAL_SESSION on mount (giving us the restored session),
    // then for SIGNED_IN, SIGNED_OUT, TOKEN_REFRESHED, etc.
    // The JWT is guaranteed to be committed before this callback runs.
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        console.log("[auth]", event, session?.user?.email ?? "no user");

        if (session?.user) {
          setUser(session.user);
          // Small delay lets Supabase client finish writing the session
          // before we make an RLS-protected query
          await new Promise(r => setTimeout(r, 100));
          const ch = await fetchChurch(session.user.id);
          setChurch(ch);
        } else {
          setUser(null);
          setChurch(null);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  // signIn just calls Supabase — onAuthStateChange handles the rest
  const signIn = async (email, password) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error: error ?? null };
  };

  // signUp calls Supabase — onAuthStateChange handles session + church fetch
  const signUp = async (email, password, churchName, adminName) => {
    const { data, error } = await supabase.auth.signUp({
      email, password,
      options: { data: { church_name: churchName, full_name: adminName } },
    });
    if (error) return { error };
    const needsEmailConfirm = !data.session || data.user?.identities?.length === 0;
    return { error: null, needsEmailConfirm };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    // onAuthStateChange will set user=null, church=null
  };

  const retryLoadChurch = useCallback(async () => {
    if (!user?.id) return false;
    const ch = await fetchChurch(user.id);
    if (ch) { setChurch(ch); return true; }
    return false;
  }, [user?.id]);

  const updateChurch = useCallback(async (updates) => {
    if (!church?.id) return { error: new Error("No church loaded") };
    const { data, error } = await supabase
      .from("churches").update(updates).eq("id", church.id).select().single();
    if (!error && data) setChurch(data);
    return { data, error };
  }, [church?.id]);

  return (
    <AuthContext.Provider value={{
      user: user ?? null, church, loading, isAuthenticated,
      signIn, signUp, signOut, updateChurch, retryLoadChurch,
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
};