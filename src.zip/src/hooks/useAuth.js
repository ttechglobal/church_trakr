// src/hooks/useAuth.js
// Re-export for convenience — import from here in components
export { useAuth } from "../contexts/AuthContext";
